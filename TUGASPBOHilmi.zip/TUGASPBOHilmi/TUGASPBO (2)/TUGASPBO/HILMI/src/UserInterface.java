import java.sql.*;
 
//interface
public interface UserInterface {
    public void kodeKonsumen()  throws SQLException;
    public void namaProduk();
    public void hargaSatuan();
    public void jumlah();
    public void hargaAwal();
    public void diskonProduk();
    public void totalBayar();
    public void tabelProdukMie();

}
